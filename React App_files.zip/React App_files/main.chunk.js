(this["webpackJsonpavenir-green"] = this["webpackJsonpavenir-green"] || []).push([["main"],{

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/App.css":
/*!************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--6-oneOf-3-1!./node_modules/postcss-loader/src??postcss!./src/App.css ***!
  \************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".App {\n  text-align: center;\n}\n\n.App-logo {\n  height: 40vmin;\n  pointer-events: none;\n}\n\n@media (prefers-reduced-motion: no-preference) {\n  .App-logo {\n    animation: App-logo-spin infinite 20s linear;\n  }\n}\n\n.App-header {\n  background-color: #282c34;\n  min-height: 100vh;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  font-size: calc(10px + 2vmin);\n  color: white;\n}\n\n.App-link {\n  color: #61dafb;\n}\n\n@keyframes App-logo-spin {\n  from {\n    transform: rotate(0deg);\n  }\n  to {\n    transform: rotate(360deg);\n  }\n}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/components/Login.css":
/*!*************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--6-oneOf-3-1!./node_modules/postcss-loader/src??postcss!./src/components/Login.css ***!
  \*************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "#logo {\r\n    width: 157px;\r\n    height: 59px;\r\n}\r\n\r\n#background {\r\n    width: 100%;\r\n}\r\n\r\n#title-login {\r\n    width: 30rem;\r\n    height: 135px;\r\n    font-family: Montserrat;\r\n    font-weight: bold;\r\n    font-stretch: normal;\r\n    line-height: normal;\r\n    letter-spacing: normal;\r\n    color: rgba(33, 33, 33, 0.8);\r\n}\r\n\r\n#title-login > h1 {\r\n    font-size: 50px;\r\n}\r\n\r\n#title-login + p {\r\n    color: rgba(33, 33, 33, 0.8);\r\n}\r\n\r\np #avenir-green {\r\n    width: 559px;\r\n    height: 20px;\r\n    font-family: Montserrat;\r\n    font-size: 16px;\r\n    font-weight: 600;\r\n    font-stretch: normal;\r\n    font-style: normal;\r\n    line-height: normal;\r\n    letter-spacing: normal;\r\n    color: #53C872;\r\n}\r\n\r\ninput#password:focus {\r\n    background-image: none;\r\n}\r\n\r\n#form {\r\n    margin-top: 2.3rem;\r\n}\r\n\r\n#form-forgot {\r\n    /*width: 100%;*/\r\n    height: 19px;\r\n    font-family: Montserrat;\r\n    text-align: center;\r\n    font-size: 12px;\r\n    font-weight: 600;\r\n    font-stretch: normal;\r\n    font-style: normal;\r\n    line-height: 0.75;\r\n    letter-spacing: normal;\r\n    color: rgba(33, 33, 33, 0.8);\r\n}\r\n\r\n#form-submit {\r\n    width: 124px;\r\n    height: 50px;\r\n    border-radius: 5px;\r\n    background-color: #53C872;\r\n}\r\n\r\n#form-submit + span {\r\n    /*width: 90px;*/\r\n    height: 18px;\r\n    font-family: Montserrat;\r\n    font-size: 14px;\r\n    font-weight: bold;\r\n    font-stretch: normal;\r\n    font-style: normal;\r\n    line-height: 1.29;\r\n    letter-spacing: normal;\r\n    color: #fefefe;\r\n}\r\n\r\n#form-button {\r\n    text-align: center;\r\n    margin-top: 2.5rem;\r\n}\r\n\r\n#form-contact {\r\n    /*width: 100%;*/\r\n    height: 19px;\r\n    font-family: Montserrat;\r\n    text-align: center;\r\n    margin-top: 1.5rem;\r\n    font-size: 12px;\r\n    font-weight: 600;\r\n    font-stretch: normal;\r\n    font-style: normal;\r\n    line-height: 1.58;\r\n    letter-spacing: normal;\r\n    color: rgba(33, 33, 33, 0.8);\r\n}\r\n\r\n#link-contact {\r\n    color: #53C872;\r\n}\r\n\r\ndiv#copyright {\r\n    position: absolute;\r\n    bottom: 0;\r\n    width: 80%;\r\n}\r\n\r\ndiv#copyright p {\r\n    text-align: center;\r\n    font-family: Montserrat;\r\n    font-size: 12px;\r\n    font-weight: 500;\r\n    font-stretch: normal;\r\n    font-style: normal;\r\n    line-height: 1.32;\r\n    letter-spacing: normal;\r\n    color: #212121;\r\n}\r\n\r\n@media (max-width: 575px) {\r\n\r\n    #form-background {\r\n        display: none;\r\n    }\r\n\r\n    #form-login {\r\n        width: 100%;\r\n        max-width: 575px;\r\n        min-width: 300px;\r\n    }\r\n\r\n    #title-login {\r\n        width: 100%;\r\n        max-width: 575px;\r\n        min-width: 250px;\r\n        height: 45px;\r\n        font-family: Montserrat;\r\n        font-weight: bold;\r\n        font-stretch: normal;\r\n        line-height: normal;\r\n        letter-spacing: normal;\r\n        color: rgba(33, 33, 33, 0.8);\r\n    }\r\n\r\n    .vtr-center {\r\n        position: absolute;\r\n        top: 50%;\r\n        left: 50%;\r\n        height:auto;\r\n        margin-left: -230px;\r\n        margin-top: -160px;\r\n        padding: 20px 40px 16px 40px;\r\n    }\r\n\r\n    #logo {\r\n        width: 147px;\r\n        height: 49px;\r\n    }\r\n\r\n    #title-login > h1 {\r\n        font-size: 25px;\r\n    }\r\n\r\n    #form-submit {\r\n        width: 130px;\r\n        height: 40px;\r\n    }\r\n\r\n    #form-button {\r\n        margin-top: 1rem;\r\n    }\r\n\r\n    #form {\r\n        margin-top: 1rem;\r\n    }\r\n\r\n    #form-contact {\r\n        margin-top: 1rem;\r\n    }\r\n\r\n    div#copyright {\r\n        display: none;\r\n    }\r\n}\r\n\r\n/*************************** STATUS *****************************/\r\n\r\n.icon-status {\r\n    background-color: #C1C1C1;\r\n    text-align: center;\r\n    margin-top: 75px;\r\n    margin-left: 25px;\r\n    width: 54px;\r\n    height: 54px;\r\n    border-radius: 50%;\r\n}\r\n\r\n.icon-status > img {\r\n    margin-top: 10px;\r\n    width: 30px;\r\n    height: 30px;\r\n}\r\n\r\n#sncf {\r\n    width: 258px;\r\n    height: 101px;\r\n    margin-left: 27%;\r\n}\r\n\r\n.container-status {\r\n    margin-top: 55px;\r\n}\r\n\r\n#info-contact {\r\n    width: 363px;\r\n    height: 18px;\r\n    font-family: Montserrat;\r\n    font-size: 20px;\r\n    font-weight: bold;\r\n    font-stretch: normal;\r\n    font-style: normal;\r\n    line-height: 0.9;\r\n    letter-spacing: normal;\r\n    color: #212121;\r\n}\r\n\r\n.info-mg {\r\n    width: 20px;\r\n    height: 16px;\r\n    background-color: #53C872;\r\n}\r\n\r\n.info-cont {\r\n    font-family: Montserrat;\r\n    font-weight: 600;\r\n    font-stretch: normal;\r\n    font-style: normal;\r\n    line-height: 1.29;\r\n    letter-spacing: normal;\r\n    color: #212121;\r\n}\r\n\r\n#contact-button {\r\n    padding-left: 84.8px;\r\n}\r\n\r\n.shadow-sm{\r\n    width: 94%;\r\n}\r\n\r\n#card-status {\r\n    border-radius: 10px;\r\n}\r\n\r\n.card-text {\r\n    min-height: 60px;\r\n}\r\n\r\n.file-list {\r\n    color: #53C872;\r\n    font-size: 15px;\r\n}\r\n\r\nh2#tile-project {\r\n    text-transform: uppercase;\r\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/index.css":
/*!**************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--6-oneOf-3-1!./node_modules/postcss-loader/src??postcss!./src/index.css ***!
  \**************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "body {\n  margin: 0;\n  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',\n    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',\n    sans-serif;\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n}\n\ncode {\n  font-family: source-code-pro, Menlo, Monaco, Consolas, 'Courier New',\n    monospace;\n}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./src/App.css":
/*!*********************!*\
  !*** ./src/App.css ***!
  \*********************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-3-1!../node_modules/postcss-loader/src??postcss!./App.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/App.css");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(true) {
	module.hot.accept(/*! !../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-3-1!../node_modules/postcss-loader/src??postcss!./App.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/App.css", function() {
		var newContent = __webpack_require__(/*! !../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-3-1!../node_modules/postcss-loader/src??postcss!./App.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/App.css");

		if(typeof newContent === 'string') newContent = [[module.i, newContent, '']];

		var locals = (function(a, b) {
			var key, idx = 0;

			for(key in a) {
				if(!b || a[key] !== b[key]) return false;
				idx++;
			}

			for(key in b) idx--;

			return idx === 0;
		}(content.locals, newContent.locals));

		if(!locals) throw new Error('Aborting CSS HMR due to changed css-modules locals.');

		update(newContent);
	});

	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./src/App.js":
/*!********************!*\
  !*** ./src/App.js ***!
  \********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Login__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./components/Login */ "./src/components/Login.js");
/* harmony import */ var _components_Contact__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/Contact */ "./src/components/Contact.js");
/* harmony import */ var _components_SpaceClient__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/SpaceClient */ "./src/components/SpaceClient.js");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var _App_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./App.css */ "./src/App.css");
/* harmony import */ var _App_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_App_css__WEBPACK_IMPORTED_MODULE_5__);
var _jsxFileName = "C:\\wamp64\\www\\avenir-green\\avenir-green\\src\\App.js";







function App() {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_4__["BrowserRouter"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 10,
      columnNumber: 7
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_4__["Route"], {
    exact: true,
    path: "/",
    component: _components_Login__WEBPACK_IMPORTED_MODULE_1__["default"],
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 11
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_4__["Route"], {
    exact: true,
    path: "/contact",
    component: _components_Contact__WEBPACK_IMPORTED_MODULE_2__["default"],
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 12,
      columnNumber: 11
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_4__["Route"], {
    exact: true,
    path: "/client",
    component: _components_SpaceClient__WEBPACK_IMPORTED_MODULE_3__["default"],
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 11
    }
  }));
}

/* harmony default export */ __webpack_exports__["default"] = (App);

/***/ }),

/***/ "./src/components/Contact.js":
/*!***********************************!*\
  !*** ./src/components/Contact.js ***!
  \***********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _images_Logo__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./images/Logo */ "./src/components/images/Logo.js");
/* harmony import */ var _images_BackgroundContact__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./images/BackgroundContact */ "./src/components/images/BackgroundContact.js");
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/index.js");
/* harmony import */ var _Login_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Login.css */ "./src/components/Login.css");
/* harmony import */ var _Login_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_Login_css__WEBPACK_IMPORTED_MODULE_4__);
var _jsxFileName = "C:\\wamp64\\www\\avenir-green\\avenir-green\\src\\components\\Contact.js";






class Login extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(...args) {
    super(...args);
    this.state = {
      demande: '',
      prenom: '',
      nom: '',
      email: '',
      message: ''
    };
  }

  handleSubmit(event) {
    event.preventDefault();
  }

  render() {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      className: "container",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 23,
        columnNumber: 13
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_images_Logo__WEBPACK_IMPORTED_MODULE_1__["default"], {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 24,
        columnNumber: 17
      }
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      id: "login",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 17
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      className: "row login-content",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 21
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      className: "col-md-6",
      id: "form-background",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 27,
        columnNumber: 25
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_images_BackgroundContact__WEBPACK_IMPORTED_MODULE_2__["default"], {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 28,
        columnNumber: 29
      }
    })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      id: "form-login",
      className: "col-md-5 offset-md-1 vtr-center",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 30,
        columnNumber: 25
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      className: "elm-center",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 31,
        columnNumber: 29
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 32,
        columnNumber: 33
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h2", {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 33,
        columnNumber: 37
      }
    }, "Un message \xE0 nous transmettre ? Un probl\xE8me ?")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 35,
        columnNumber: 33
      }
    }, "Remplisser le formulaire ci-dessous"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("form", {
      onSubmit: this.handleSubmit,
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 33
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      id: "form",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 37
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__["FormGroup"], {
      controlId: "demande",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 39,
        columnNumber: 41
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__["FormControl"], {
      as: "select",
      value: this.demande,
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 40,
        columnNumber: 45
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("option", {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 41,
        columnNumber: 49
      }
    }, "VOTRE TYPE DE DEMANDE"))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__["FormGroup"], {
      controlId: "prenom",
      bsSize: "large",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 44,
        columnNumber: 41
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__["FormControl"], {
      autoFocus: true,
      type: "text",
      value: this.prenom,
      placeholder: "PRENOM",
      onChange: (event, newValue) => this.setState({
        prenom: newValue
      }),
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 45,
        columnNumber: 45
      }
    })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__["FormGroup"], {
      controlId: "nom",
      bsSize: "large",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 53,
        columnNumber: 41
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__["FormControl"], {
      autoFocus: true,
      type: "text",
      value: this.nom,
      placeholder: "NOM",
      onChange: (event, newValue) => this.setState({
        nom: newValue
      }),
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 54,
        columnNumber: 45
      }
    })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__["FormGroup"], {
      controlId: "email",
      bsSize: "large",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 62,
        columnNumber: 41
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__["FormControl"], {
      autoFocus: true,
      type: "email",
      value: this.email,
      placeholder: "EMAIL PROFFESSIONNEL",
      onChange: (event, newValue) => this.setState({
        email: newValue
      }),
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 63,
        columnNumber: 45
      }
    })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__["FormGroup"], {
      controlId: "message",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 71,
        columnNumber: 41
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__["FormControl"], {
      as: "textarea",
      rows: "4",
      value: this.message,
      placeholder: "VOTRE MESSAGE",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 72,
        columnNumber: 45
      }
    }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      id: "form-button",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 79,
        columnNumber: 37
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__["Button"], {
      id: "form-submit",
      className: "btn btn-success",
      type: "submit",
      onClick: event => this.handleSubmit(event),
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 80,
        columnNumber: 41
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 81,
        columnNumber: 45
      }
    }, "ENVOYER")))))))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      id: "copyright",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 91,
        columnNumber: 17
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 92,
        columnNumber: 21
      }
    }, "By Avenir Green - Tout droits r\xE9serv\xE9s")));
  }

}

/* harmony default export */ __webpack_exports__["default"] = (Login);

/***/ }),

/***/ "./src/components/Login.css":
/*!**********************************!*\
  !*** ./src/components/Login.css ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-3-1!../../node_modules/postcss-loader/src??postcss!./Login.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/components/Login.css");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(true) {
	module.hot.accept(/*! !../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-3-1!../../node_modules/postcss-loader/src??postcss!./Login.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/components/Login.css", function() {
		var newContent = __webpack_require__(/*! !../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-3-1!../../node_modules/postcss-loader/src??postcss!./Login.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/components/Login.css");

		if(typeof newContent === 'string') newContent = [[module.i, newContent, '']];

		var locals = (function(a, b) {
			var key, idx = 0;

			for(key in a) {
				if(!b || a[key] !== b[key]) return false;
				idx++;
			}

			for(key in b) idx--;

			return idx === 0;
		}(content.locals, newContent.locals));

		if(!locals) throw new Error('Aborting CSS HMR due to changed css-modules locals.');

		update(newContent);
	});

	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./src/components/Login.js":
/*!*********************************!*\
  !*** ./src/components/Login.js ***!
  \*********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _images_Logo__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./images/Logo */ "./src/components/images/Logo.js");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var _images_Background__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./images/Background */ "./src/components/images/Background.js");
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/index.js");
/* harmony import */ var _Login_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Login.css */ "./src/components/Login.css");
/* harmony import */ var _Login_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_Login_css__WEBPACK_IMPORTED_MODULE_5__);
var _jsxFileName = "C:\\wamp64\\www\\avenir-green\\avenir-green\\src\\components\\Login.js";







class Login extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(...args) {
    super(...args);
    this.state = {
      email: '',
      password: ''
    };

    this.handleEmail = e => {
      this.setState({
        email: e.target.value
      });
    };

    this.handlePassword = e => {
      this.setState({
        password: e.target.value
      });
    };
  }

  handleSubmit(event) {
    event.preventDefault();

    if (this.state.email === 'client@contact.com' && this.state.password === 'client') {
      console.log("REdirection . . .");
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_2__["Redirect"], {
        to: "/client",
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 27,
          columnNumber: 20
        }
      });
    }
  }

  render() {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      className: "container",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 33,
        columnNumber: 13
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_images_Logo__WEBPACK_IMPORTED_MODULE_1__["default"], {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 34,
        columnNumber: 17
      }
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      id: "login",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 35,
        columnNumber: 17
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      className: "row login-content align-items-center",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 21
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      className: "col-md-6",
      id: "form-background",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 37,
        columnNumber: 25
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_images_Background__WEBPACK_IMPORTED_MODULE_3__["default"], {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 29
      }
    })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      id: "form-login",
      className: "col-md-5 offset-md-1 vtr-center",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 40,
        columnNumber: 25
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      className: "elm-center",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 41,
        columnNumber: 29
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      id: "title-login",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 42,
        columnNumber: 33
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h1", {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 43,
        columnNumber: 37
      }
    }, "Bienvenue dans votre espace client")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 45,
        columnNumber: 33
      }
    }, "Propos\xE9 par ", /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
      id: "avenir-green",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 45,
        columnNumber: 48
      }
    }, "Avenir Green")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("form", {
      onSubmit: this.handleSubmit,
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 46,
        columnNumber: 33
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      id: "form",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 48,
        columnNumber: 37
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__["FormGroup"], {
      controlId: "email",
      bsSize: "large",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 49,
        columnNumber: 41
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__["FormControl"], {
      autoFocus: true,
      type: "email",
      value: this.email,
      placeholder: "EMAIL",
      onChange: this.handleEmail,
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 50,
        columnNumber: 45
      }
    })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__["FormGroup"], {
      controlId: "password",
      bsSize: "large",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 58,
        columnNumber: 41
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__["FormControl"], {
      value: this.password,
      placeholder: "MOT DE PASSE",
      onChange: this.handlePassword,
      type: "password",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 59,
        columnNumber: 45
      }
    })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", {
      id: "form-forgot",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 67,
        columnNumber: 41
      }
    }, "Oups, mot de passe oubli\xE9 ?")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      id: "form-button",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 70,
        columnNumber: 37
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_2__["Link"], {
      id: "form-submit",
      className: "btn btn-success",
      to: "/client",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 71,
        columnNumber: 41
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 72,
        columnNumber: 45
      }
    }, "CONNEXION"))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", {
      id: "form-contact",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 75,
        columnNumber: 37
      }
    }, "Vous rencontrez un probl\xE8me ? ", /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_2__["Link"], {
      id: "link-contact",
      to: "/contact",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 75,
        columnNumber: 88
      }
    }, "Contactez nous"))))))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      id: "copyright",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 82,
        columnNumber: 17
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 83,
        columnNumber: 21
      }
    }, "By Avenir Green - Tout droits r\xE9serv\xE9s")));
  }

}

/* harmony default export */ __webpack_exports__["default"] = (Login);

/***/ }),

/***/ "./src/components/SpaceClient.js":
/*!***************************************!*\
  !*** ./src/components/SpaceClient.js ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-bootstrap */ "./node_modules/react-bootstrap/esm/index.js");
/* harmony import */ var _Login_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Login.css */ "./src/components/Login.css");
/* harmony import */ var _Login_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_Login_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _images_Logo__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./images/Logo */ "./src/components/images/Logo.js");
/* harmony import */ var _images_Sncf__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./images/Sncf */ "./src/components/images/Sncf.js");
/* harmony import */ var _images_client_DateRange__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./images/client/DateRange */ "./src/components/images/client/DateRange.js");
var _jsxFileName = "C:\\wamp64\\www\\avenir-green\\avenir-green\\src\\components\\SpaceClient.js";







class SpaceClient extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
  constructor(...args) {
    super(...args);
    this.state = {
      projects: [],
      status: [],
      projectName: ''
    };

    this.handleProjectName = e => {
      this.setState({
        projectName: e.target.value
      });
    };
  }

  componentDidMount() {
    fetch('http://127.0.0.1:8000/api/projects').then(response => response.json()).then(result => {
      this.setState({
        projects: result['hydra:member']
      });
    });
    fetch('http://127.0.0.1:8000/api/statuses').then(response => response.json()).then(result => {
      console.log(result['hydra:member'][2].file);
      this.setState({
        status: result['hydra:member']
      });
    });
  }

  render() {
    const projects = this.state.projects;
    const status = this.state.status;
    const projectName = this.state.projectName;
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      className: "container mt-3",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 43,
        columnNumber: 13
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_images_Logo__WEBPACK_IMPORTED_MODULE_3__["default"], {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 44,
        columnNumber: 17
      }
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_images_Sncf__WEBPACK_IMPORTED_MODULE_4__["default"], {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 45,
        columnNumber: 17
      }
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h2", {
      className: "text-center mt-5",
      id: "tile-project",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 47,
        columnNumber: 17
      }
    }, projectName), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      className: "container-status",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 49,
        columnNumber: 17
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("form", {
      onSubmit: this.handleSubmit,
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 50,
        columnNumber: 21
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      className: "row",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 51,
        columnNumber: 25
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      className: "col-md-5",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 52,
        columnNumber: 29
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_1__["FormGroup"], {
      controlId: "demande",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 53,
        columnNumber: 33
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_1__["FormControl"], {
      as: "select",
      value: this.state.projectName,
      onChange: this.handleProjectName,
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 54,
        columnNumber: 29
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("option", {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 55,
        columnNumber: 33
      }
    }, "SELECTIONNER UN PROJET"), projects.map(project => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("option", {
      key: project.id,
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 57,
        columnNumber: 37
      }
    }, project.name))))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      className: "col-md-4",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 64,
        columnNumber: 29
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_1__["Button"], {
      className: "btn btn-success",
      type: "submit",
      onClick: event => this.handleSubmit(event),
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 65,
        columnNumber: 33
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_images_client_DateRange__WEBPACK_IMPORTED_MODULE_5__["default"], {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 66,
        columnNumber: 29
      }
    }), " Consulter le planning du projet")))), status.map(stat => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      className: "row",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 74,
        columnNumber: 25
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      className: "col-md-1",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 75,
        columnNumber: 29
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      className: "icon-status",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 76,
        columnNumber: 33
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("img", {
      src: __webpack_require__("./src/components/images/logo sync recursive ^\\.\\/.*$")(`./${stat.logoName}`),
      alt: "",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 77,
        columnNumber: 37
      }
    }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      className: "col-md-11",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 80,
        columnNumber: 29
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      className: "shadow-sm p-1 mb-1 bg-light rounded mt-5",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 81,
        columnNumber: 33
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
      id: "card-status",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 82,
        columnNumber: 37
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_1__["Card"].Body, {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 83,
        columnNumber: 41
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_1__["Card"].Title, {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 84,
        columnNumber: 45
      }
    }, stat.name), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_1__["Card"].Subtitle, {
      className: "mb-2 text-muted",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 85,
        columnNumber: 45
      }
    }, "Phrase explicative de la section"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 86,
        columnNumber: 45
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("hr", {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 86,
        columnNumber: 50
      }
    })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_1__["Card"].Text, {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 87,
        columnNumber: 45
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_1__["Badge"], {
      variant: "secondary",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 89,
        columnNumber: 49
      }
    }, "Documents"), stat.file.length > 0 && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("ul", {
      className: "file-list",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 92,
        columnNumber: 49
      }
    }, stat.file.map(f => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("li", {
      key: f.id,
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 94,
        columnNumber: 57
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("a", {
      href: "/",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 95,
        columnNumber: 61
      }
    }, f.filename))))))))))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      className: "row justify-content-between mt-md-5",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 109,
        columnNumber: 21
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      className: "col-md-4",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 110,
        columnNumber: 25
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", {
      id: "info-contact",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 111,
        columnNumber: 29
      }
    }, "Nom Pr\xE9nom du contact du projet"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", {
      className: "info-cont",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 112,
        columnNumber: 29
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("img", {
      className: "info-img",
      src: __webpack_require__(/*! ./images/logo/mail_outline-24px.svg */ "./src/components/images/logo/mail_outline-24px.svg"),
      alt: "",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 112,
        columnNumber: 54
      }
    }), " toto@gmail.com"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", {
      className: "info-cont",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 113,
        columnNumber: 29
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("img", {
      className: "info-img",
      src: __webpack_require__(/*! ./images/logo/call-24px.svg */ "./src/components/images/logo/call-24px.svg"),
      alt: "",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 113,
        columnNumber: 54
      }
    }), "06.00.00.00.00")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      className: "col-md-4",
      id: "contact-button",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 115,
        columnNumber: 25
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_bootstrap__WEBPACK_IMPORTED_MODULE_1__["Button"], {
      className: "btn btn-success",
      type: "submit",
      onClick: event => this.handleSubmit(event),
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 116,
        columnNumber: 29
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 117,
        columnNumber: 33
      }
    }, "FAIRE UNE DEMANDE DE CONTACT"))))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
      className: "mt-5 text-center",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 122,
        columnNumber: 17
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 123,
        columnNumber: 21
      }
    }, "By Avenir Green - Tout droits r\xE9serv\xE9s")));
  }

}

/* harmony default export */ __webpack_exports__["default"] = (SpaceClient);

/***/ }),

/***/ "./src/components/images/Background.js":
/*!*********************************************!*\
  !*** ./src/components/images/Background.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _background_jpg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./background.jpg */ "./src/components/images/background.jpg");
/* harmony import */ var _background_jpg__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_background_jpg__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\wamp64\\www\\avenir-green\\avenir-green\\src\\components\\images\\Background.js";



const Background = () => {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("img", {
    id: "background",
    src: _background_jpg__WEBPACK_IMPORTED_MODULE_1___default.a,
    alt: "",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 6,
      columnNumber: 9
    }
  });
};

/* harmony default export */ __webpack_exports__["default"] = (Background);

/***/ }),

/***/ "./src/components/images/BackgroundContact.js":
/*!****************************************************!*\
  !*** ./src/components/images/BackgroundContact.js ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _backgroundContact_jpg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./backgroundContact.jpg */ "./src/components/images/backgroundContact.jpg");
/* harmony import */ var _backgroundContact_jpg__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_backgroundContact_jpg__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\wamp64\\www\\avenir-green\\avenir-green\\src\\components\\images\\BackgroundContact.js";



const BackgroundContact = () => {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("img", {
    id: "background",
    src: _backgroundContact_jpg__WEBPACK_IMPORTED_MODULE_1___default.a,
    alt: "",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 6,
      columnNumber: 9
    }
  });
};

/* harmony default export */ __webpack_exports__["default"] = (BackgroundContact);

/***/ }),

/***/ "./src/components/images/Logo.js":
/*!***************************************!*\
  !*** ./src/components/images/Logo.js ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _logo_jpg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./logo.jpg */ "./src/components/images/logo.jpg");
/* harmony import */ var _logo_jpg__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_logo_jpg__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\wamp64\\www\\avenir-green\\avenir-green\\src\\components\\images\\Logo.js";



const PastedGraphic = () => {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("img", {
    id: "logo",
    src: _logo_jpg__WEBPACK_IMPORTED_MODULE_1___default.a,
    alt: "",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 6,
      columnNumber: 9
    }
  });
};

/* harmony default export */ __webpack_exports__["default"] = (PastedGraphic);

/***/ }),

/***/ "./src/components/images/Sncf.js":
/*!***************************************!*\
  !*** ./src/components/images/Sncf.js ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _sncf_JPG__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sncf.JPG */ "./src/components/images/sncf.JPG");
/* harmony import */ var _sncf_JPG__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_sncf_JPG__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\wamp64\\www\\avenir-green\\avenir-green\\src\\components\\images\\Sncf.js";



const Sncf = () => {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("img", {
    id: "sncf",
    src: _sncf_JPG__WEBPACK_IMPORTED_MODULE_1___default.a,
    alt: "",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 6,
      columnNumber: 9
    }
  });
};

/* harmony default export */ __webpack_exports__["default"] = (Sncf);

/***/ }),

/***/ "./src/components/images/background.jpg":
/*!**********************************************!*\
  !*** ./src/components/images/background.jpg ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/background.1d7ccdf4.jpg";

/***/ }),

/***/ "./src/components/images/backgroundContact.jpg":
/*!*****************************************************!*\
  !*** ./src/components/images/backgroundContact.jpg ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/backgroundContact.52582867.jpg";

/***/ }),

/***/ "./src/components/images/client/DateRange.js":
/*!***************************************************!*\
  !*** ./src/components/images/client/DateRange.js ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _logo_date_range_24px_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../logo/date_range-24px.svg */ "./src/components/images/logo/date_range-24px.svg");
/* harmony import */ var _logo_date_range_24px_svg__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_logo_date_range_24px_svg__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\wamp64\\www\\avenir-green\\avenir-green\\src\\components\\images\\client\\DateRange.js";



const DateRange = () => {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("img", {
    id: "date_range",
    src: _logo_date_range_24px_svg__WEBPACK_IMPORTED_MODULE_1___default.a,
    alt: "",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 6,
      columnNumber: 9
    }
  });
};

/* harmony default export */ __webpack_exports__["default"] = (DateRange);

/***/ }),

/***/ "./src/components/images/logo sync recursive ^\\.\\/.*$":
/*!**************************************************!*\
  !*** ./src/components/images/logo sync ^\.\/.*$ ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./Visible.png": "./src/components/images/logo/Visible.png",
	"./account_balance-24px.svg": "./src/components/images/logo/account_balance-24px.svg",
	"./arrow-ios-downward-outline.svg": "./src/components/images/logo/arrow-ios-downward-outline.svg",
	"./call-24px.svg": "./src/components/images/logo/call-24px.svg",
	"./check-24px.svg": "./src/components/images/logo/check-24px.svg",
	"./date_range-24px.svg": "./src/components/images/logo/date_range-24px.svg",
	"./emoji_events-24px.svg": "./src/components/images/logo/emoji_events-24px.svg",
	"./euro_symbol-24px.svg": "./src/components/images/logo/euro_symbol-24px.svg",
	"./import_contacts-24px.svg": "./src/components/images/logo/import_contacts-24px.svg",
	"./logo-Avenir_Green.svg": "./src/components/images/logo/logo-Avenir_Green.svg",
	"./mail_outline-24px.svg": "./src/components/images/logo/mail_outline-24px.svg",
	"./people_alt-24px.svg": "./src/components/images/logo/people_alt-24px.svg",
	"./rocket-ship.jpg": "./src/components/images/logo/rocket-ship.jpg",
	"./rocket-ship1.png": "./src/components/images/logo/rocket-ship1.png",
	"./speed-24px.svg": "./src/components/images/logo/speed-24px.svg"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "./src/components/images/logo sync recursive ^\\.\\/.*$";

/***/ }),

/***/ "./src/components/images/logo.jpg":
/*!****************************************!*\
  !*** ./src/components/images/logo.jpg ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEANQA1AAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCAA4AMYDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD3+iiigAopCwUZYgD1JpaACiiigAooooAKKKKACiiigAooooAKKKKACiikJwM0ABIAyTgCs+41q1gO1SZW/wBnp+dZ12dS1F28uB1hB+VScZrFu0mtX2TxtGx6Z7/SuGriZr4Fp3OWpXkvhR0C+JIt+HgYL6hs1sQTx3MKyxMGRhwRXnTze9dJ4RuGkjuoSflVgw/H/wDVRh685S5ZEUcRKU+WR0tFFFdx2hRRRQBj+Jtdj8P6PJdNhpm+SCMgne56Dj8/wrjtM127it76U6ldXEdtf25klnjKKVfaHAyOBk9PSu7vNMjvb6xuZXbFo7Okf8LMRgE/TJ/OsybwxHeprlveSZttSkR8Jwy4VR/NaxnGbldHPUhUcrr+tP8AMx9Yv21DTbrX5wx02zz9gt+cXEmcLIw7jP3R+NS+GtMivXju7g63I8IVhNeTPGkj99seRxn1FdHqGjW2oaMdMJaGEKojaPgxlcbSPpgVWsNCuLe8+2X2r3V9OqFI94VEQHqQqjBPuaXI+a71F7OXOm9TBuPF7ReLdWUOx0/TbE5QDiWcsOB6nkD8akm0a9tfCr3tzqt9b3iRyXU6wSAAyNzg5B4HAx7Vbh8D2cV1p8zXMrra7mkRgMXDl94Zvo3NaWtaG2tKIn1K7t7YqVkhgKgSA+pIzSUJtNyEoTabl8jFnguLD4ftd3Orag8qwLdSSeYA+doJQEDhc1Y8GXeqXds8t000li0aNBJc7fNLEfMPl6r6E81dtfCtha2E9mZbueKePynE9wz/AC+gzwPwpbXw8ml6ktxpcxtrZxie0xmN+OGUfwt9OtNQkpJlKE1JP9SfxBqx0bSmuY4fOnd1hhjzgNIxwoJ7DNcprEY06NJ/Eesau106+YrWEbiCAjsAvX/gWc12uoafbapYyWd3H5kMgwRnBHoQexHrWMPDepKvkp4n1AW2MbGSNnx6byufxp1IybHVjJvTX+vkYfiTVCL/AEi4sNS1Jv7QjJiS2K44XIO08Ek9cmruv6vqNn4Z023vTJBqN86xTNaKWdF6sVAzzj07mtb/AIRHRjZ2lpJa+bFao6RiRs/e6n655zVZvC1wYIYxrE4ls5S9lcFQ0kakYKNnhx7nmpcJ6+ZDhU18/wCmU7VLfRtEvPEDRaossUTbFv7hmZh2JXOBk496r+GtPXVTHc3p1uSRAsrS3EzxRNIeSqJkEge4xW2vheKXTb61v766vJb1QJZ3YAjHTaBwuKdp+gXEF7FdX+r3V+8AKwo6qiLnjJCjk+5p8jutNBqnK600Ma/8VmDxvNbCVhp+n2MktxgcPJxgZ9R0+pra8L2l1DpZu74sby+c3Eqk8Ju6KPoMCqDeBrR57OWS6mfyZXlmBA/0jc27DewOPyrqqqEZczciqcZ8zcwrN1jXdP0OAS3swUt9xByzfQVpVjPc6Bfa4bJza3GopHyjKGKqOoz0HXpWqcU/eNKkakov2e5y5+JyfagBpp+z55Jk+bH0rovETQ3nh0XkZBUbZEb2NeT+MIYLDxXe2dkuIwRtRegJHQfia9D11zpng2wsHP71lRSPoMmtMXGmqV11PFwmIxEnVhXd0vzOaeb3rrvBEbG2upz0Zwo/Af8A164EyNI6pGCzscKB3NetaLp40zSYLX+JVy59WPJrzMND3r9jpwcXKpzdi/RRRXeeoFFFFABVa/nNrp88653IhI4zzVmigDmxdXtsLbzbyZhKxcIYwXKBe+BwCf505dSu3tbQtJLC9xMMN5YJdT12jqAPU10OBnOKMDOcUAc9LPqjW1y4nzL5pggjiQKCf7xJz05/Kp9I1R7mcW80mJEiVShHJcZ3HP4Vt0mB6UAYmr6lLZ6naqrssAwZQFyWycDHr7+lXdWu5rSy32wDTMwVFxkt9Pf61ewD1ApaAObfWNRELIkX75X2FSnzZ4wB2Jxk+lSNdali6eSb/U7VSKKMAu5HQk56cdK6CigDmIdSvI0tYZ538+JZBPGE3FmHTJxwDmoW1fVnRJGjZPszZuMDHA4P15IP4V1mBnOKMCgDltN1e+EkL3s2Ip3yjEcFQOQAAOSa09IupNQuLi4aZvLVyscYI2hexPGc1rYHpQAB0GKAFooooA5rxnrq6NpsEX2pbWS9mECzt0iX+JvwH6msPTv7L0hLrxT9mFvp1tbmCzLjElzzkyHPJLHgZ5xzXa3+lWGqCIX1pDcCJ96CVd20+tZuteFbPxBeWz6jLLJZ2wylmp2xs3q2OT9Ky9nzVOaWyLlUlGk4092ee+BtCu/E+vS+J9VQraCUyxhv+Wj5/wDQVqbxTrQ1XV3eNs28P7uP39TXQ+NNdi0m0GkWD+XIyYdUwBEnoMdzWP4X8HT6o6Xmoo0VkOVjPDS/4CliKjqy5EeJKnb9xS1e7fmaHgfQWnlXV7pMRL/x7qw+8f73+Feg1mXC2NnEFe68lVGFXf0HoBWC+sKHYLLuXPBPerhBQVkenRpKlDlR2NFcemqPIcRh3PooJrQt01KYgiNox6ucVZqdBRTIVdIlWR97ActjrRQA+iiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKa4YxsEbaxHDEZwaKKAOVtvBEUN497LeG4u3bcZZYg2D7A8VpvoMk4xcatfOD/CrBB+QFFFJRS2JhCMFaKGp4U0tTl0lkPq8hNXItG02D7lnFn3XP86KKZRdSNIxhEVR6AYp1FFABRRRQB//Z"

/***/ }),

/***/ "./src/components/images/logo/Visible.png":
/*!************************************************!*\
  !*** ./src/components/images/logo/Visible.png ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAACxLAAAsSwGlPZapAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAgvSURBVHgB7Zy9bhtHEMdn70iLdoowL5AwDqwYTmEaUFIFEIXYibtIiFVbLgIrlaQnkPQEkoAAkZMiUmfAhkVV8RdipnOhwEyjqPAH/QZMEZvyHW8yc0cChEjeHcnZI0Psr7GtW/PEnd3Z2f/MLoDBYDAYDAaDwWAwGAwGg8FgMBgMBoPBMM4oGFEKs8vZVKqWVwpyCtVFUF4O0aK/Y9ZTmFWgsq3tEbBqoaqigopSWAW0Kh7UXwNYZdfNlEvFzSqMICNjAO7wU/ZxgX6jaUCcpY7MgSiqDArLylP77+oTpVExyFANEIzyNwsKrG/5n5AsJfBg1/GAjLFdgSExFANcvrZIIx2XyG8UTrqSoaBgBxF2H9/dLkHCJGoA7nh64SokP9pjQm7Kw61H97Z3ICESMcDod/wJaCGHOqwnYQitBrgy/30e0N6A/0vHn4CiqeI7R63oXCO0GMCPaFK1JQRYgzGAOmnt4d3tddCAuAH8Ue/ZeyAeRg4ZckuOAzPSs8ECQa7M36TIxn42dp3PIOTSKXj19bXFVRBEZAawy5mwaxueggXQBLmzkkL4ywOvVK9bZYBMtbmZ4ven0//mPE/llLLy9KNppXHdUYCb79zT6xKbuYENUJhdpJGh9qiL8iAOVhHUFkkJm71+2av0e9XTtM/wYBW1zEhVdlycG9QlDWQAv/NteCLvcrjjrfXHd3/aBAGuzC8uaDGEwLpgQ59o63yELad+eu73ez+WQIiXhwflc59O7ZMBPqDfV3KmZm0bZj+cnNqvHB305Y76mgG6Op/czYrUqO/G5Ws/LJMP3wBJBpgJPRtAT+f7vn4uKS3G16IA90R1qD6N0JMB/GjDrj2TH/kwk7QQ1pBHnoAovDBPzPQSMPS0D0il3/6qx+0kr0LyO/ndIArmT3Ef9UDsGcAbEHFpgWTgR3e2b8Rt3iJxFGhPkGtGNZwNI3dSRvD2Xdcq9uIGvvpucdNSsASC9CJdxDJAQ1R7BoJQqrFikc+8H6Ozgr0G8MgqQBzIsOSP10uxPnuBkkITr6TzEnHdamQYyl/eVtZv9KVkEycerDzci/4FWd6wLLhNHXQe4pO3LbVw7sLnxy8OD56GNawclWtnL3xxTCPxKghCA6zw4eSXu5Wjp7WwdpFrAEU8q9J+n0d/HK3d111QbfY3Oil5T+FmHO2GQ192YyAJuchTqbeR7w41gO96NOg7SMmOqDY88iXWHP6Mbyj2j26ptkAYWuSXg5C3O+EzgGVlDdiUCA97zm6PcrRrIIRH2Tj+zLA2rlvTsgGk2Ru66etqANZPdMjKrGpGLbzs9mQXRcw2FvGulIo77IJKIA7mw2Zg9xnggaju3cIfYQ/9kapH1i5wGBvWwCO5GzQQzMDO7+5oAF2j338heuWw56mUNwuaSKVqEWuBVwItYLbbuzvPAH2jH9DCStjzRpGWFijUnA57nvYTPbrerZY6zYI2A+gc/YzjvFcJe45aEjsNIr5XDWoayxVpHbJqbbO7fQYgim7LTxIlVGmtlMNwAzQWYn1YcL39R22okawiHgcoDxHtgqjVLmgkKhKhUVoBbYQPLtaFQCPotW/22gzgOLWi+La89YWW835oA6XPAPS9whfZ9JkcaKKb/NJmgMAPym/Lm6SUcynsOUbsEwZD7Yc9tT03B5roJr90DEN5W65rFiBYhbDnuiQBJuViMex5o6ZInDDxsaMBgllgaamFJBdzMeyxNkmAcgRREkjUPqFfwsTHrlJEUJ2AOjYmkZKA7cIN2RmIVdsJV2AbYl0BhImS3kPVUPmcaUCUJBCMVLkZyEVekQJgWk8pI0J9Lux5qAE4pUYClfiCzNvyqDZBkgQGNgJ/RqxaIx3yi5/z/iXUi0RmxOr12poSj80xGydJQgNgjWdhf+7IrzXiiou1qJY65Bd2PVFuz28HMdBUQ1N13ImP49TQ+IW2NiVoVPtWvhOcc0jROhI74a+jxFLVL0WNfiZWbejLw4PK2QtTSrjkO5OynMyLwz8fRDV8fnRQffn3QXFycmrXs7zX9O0ywbZeZfwGNENRAX/ZXdfNcF3precxazXPfTa1QZ1fAEECt/fz7Thte6qMuzx/c0+hEtXrLXITDzTXg3YjOFCiRN+NCouP79yai9u+p8o41zm+IR2acuVCVOJaB/47hTuf/b7rnI5daMb0ZADeJNmumpNelCkq2kvSCM3iXBCkWWjW60GSns+I8cJm1WFG1gh8+QY8iVc+MhjsdvhdknmHXqr82v4v9AlHJh5FDxpOncQuK+yFoK70eJVCWlEjD9L5TN8nZDjK4FMn1GGzwmWLeT518sn5qX8o8hFZb4LyRpeFuAIIMmjn+58BA+LH6Cn2p0peSWxcGdDPjSbNSmpa5Jf1pDlV2XZx7v4wD+k14UySbWfWpMu8T1DiXIGFqoyWW+HkfusxVUqpZ0/ZiksppxuJ/QLoAmHXqWeWR+KYaisUXaw1LuUYW6TPsYkagNG2OA8Z9vesbMaRF3r6XNDEOM0Glhb6OSweB20GYHg2uGm1oRBF5Yuk8K9HUPUV6VHfilYDNNF2Ul0TGKRE15M4PJiIAZqwIRCRdqIaQlYBkuz4JokaoImfX0BYiKvv6wX5rtESCXNbY39p30maN5ogwnWd18t0IhjtfKz1zM4w7xAdqgFa4c2Ubb8pWGDNkqZ+UdxNBeLhfnDf0BlzcWsUzauLaZTmFVo5tPAjchNZPqANys+GnZAX+LpivrqY/uTriz31mrTeMs2uyihfXWwwGAwGg8FgMBgMBoPBYDAYDAaDwWAwjDf/Adcap0TinZyGAAAAAElFTkSuQmCC"

/***/ }),

/***/ "./src/components/images/logo/account_balance-24px.svg":
/*!*************************************************************!*\
  !*** ./src/components/images/logo/account_balance-24px.svg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/account_balance-24px.3a3f38c3.svg";

/***/ }),

/***/ "./src/components/images/logo/arrow-ios-downward-outline.svg":
/*!*******************************************************************!*\
  !*** ./src/components/images/logo/arrow-ios-downward-outline.svg ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/arrow-ios-downward-outline.b33d018c.svg";

/***/ }),

/***/ "./src/components/images/logo/call-24px.svg":
/*!**************************************************!*\
  !*** ./src/components/images/logo/call-24px.svg ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/call-24px.fc717d51.svg";

/***/ }),

/***/ "./src/components/images/logo/check-24px.svg":
/*!***************************************************!*\
  !*** ./src/components/images/logo/check-24px.svg ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/check-24px.e294285e.svg";

/***/ }),

/***/ "./src/components/images/logo/date_range-24px.svg":
/*!********************************************************!*\
  !*** ./src/components/images/logo/date_range-24px.svg ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/date_range-24px.e254c5c4.svg";

/***/ }),

/***/ "./src/components/images/logo/emoji_events-24px.svg":
/*!**********************************************************!*\
  !*** ./src/components/images/logo/emoji_events-24px.svg ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/emoji_events-24px.62792f7b.svg";

/***/ }),

/***/ "./src/components/images/logo/euro_symbol-24px.svg":
/*!*********************************************************!*\
  !*** ./src/components/images/logo/euro_symbol-24px.svg ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/euro_symbol-24px.2b4d06c2.svg";

/***/ }),

/***/ "./src/components/images/logo/import_contacts-24px.svg":
/*!*************************************************************!*\
  !*** ./src/components/images/logo/import_contacts-24px.svg ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/import_contacts-24px.90617c88.svg";

/***/ }),

/***/ "./src/components/images/logo/logo-Avenir_Green.svg":
/*!**********************************************************!*\
  !*** ./src/components/images/logo/logo-Avenir_Green.svg ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/logo-Avenir_Green.4f37ff7c.svg";

/***/ }),

/***/ "./src/components/images/logo/mail_outline-24px.svg":
/*!**********************************************************!*\
  !*** ./src/components/images/logo/mail_outline-24px.svg ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/mail_outline-24px.cd01776d.svg";

/***/ }),

/***/ "./src/components/images/logo/people_alt-24px.svg":
/*!********************************************************!*\
  !*** ./src/components/images/logo/people_alt-24px.svg ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/people_alt-24px.30bc2b68.svg";

/***/ }),

/***/ "./src/components/images/logo/rocket-ship.jpg":
/*!****************************************************!*\
  !*** ./src/components/images/logo/rocket-ship.jpg ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEAZABkAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/wAALCACEAIQBAREA/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/9oACAEBAAA/APf6KKKKKKKKKKKKKKKKKKKKKKKKKKKSiiiilooooooooopKKKWiikpaKKKKKKKKSloopKWikpaKKKKKKKSloooopKKWiiiiiiikpaSiiloopKWiiikooopaKSlopKWikpaKKSlopKWiikpaKSlpKWiikopaSloooopKKWkpaKKKSiilooooooopKWiiiiiikopaKKKKKSlooooooopKWkpaKKKSiloooooooopKWkpaKSlpO9LRRRRRRRRRSUtJRS0UlLRRRRRRRRRRSUtJS0lLRRRRRRRRRRRRRSUUtFFFFFFFFFFFFFFJS0UUUUUUUV//2Q=="

/***/ }),

/***/ "./src/components/images/logo/rocket-ship1.png":
/*!*****************************************************!*\
  !*** ./src/components/images/logo/rocket-ship1.png ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIQAAACECAYAAABRRIOnAAAACXBIWXMAACxLAAAsSwGlPZapAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAmYSURBVHgB7Z3dVRw3FIDFAj72Gx2wqSCkgkAFcQeQCkIqgFSAUwF0gFPBOhUsqWBwBcub/0e5l9X4jEFXfyPNSKP7naNjDLszs9K30pVG0gjBMAzDMAzDMAzDMAwzDjuCyZYPHz4s9/f3j3Z2dpaLxeIQfnUAaamSkFIeqN/9ALz+Xv34/d+2bd9//vz55tWrV/emc7IQmQCFdbS7u3sMBf8z/PcICvtIxOfh69evJy9evLijXsBCTAR+u+FbewYC/Ao/HwvNNz0FUHvcQPqd+vueYEYDm4CXL1+ewo/HKAEUDIohRsZY87AQienVBL+hBBMI8Ox6TH9nIRKBMQEEhKdQAGdQExwEinAP6Q7e/wBS/QfHeIB0D3EA/l5QASIW+sePHw/29vaWEJesnvzZKATHEJH58uXLMRTEhYoLfHiAdAfv+wcK/w6O8SiCGAgc65mJUFtxuacGRYDCXGEBBKSVSARcU/P0fMAh9fqFYAYBmbtEEbBqdqwVdF2+FF3MIFiIQLCdhoRNQ+MgArb9f3/79u0EqutfxLZ56HNg+tYymYPNA1S9jUNT0IAEl08je2winr4WXncuEuDbZDAeqC7krYsI0BM4o46DhT9WHAHHXbMQCXCsFYwidGDcoXs/nkNEhmuIBEAGXllE2OiaBhO6ZgO4FpFhISKivslrW5cRh6SFJ0SzIUOOZfkMLEQMcKTR0kRsoHl4LQJR8chGc9xbERHdtQvGDyisU1ut4NM8UGAzkzKWUNKxEEPAsQWTDDG7h4ZaookhnKrlnh1bMG5YZGgwg0VksFdCnG9w06F6RqN0b2eHRYZ17GCvj67HoYK/CzEAvNOqOe5bwZgxyQBNxI1IjOrNbGJLoYtR8HeCobHIcClGgqjeB0kB77vVHCu4ZzR7cpGhg+p1qIK89g00W80YSorR0FmQmwwdJikwsHWNZaguZ4zey+zIVYYOixSPtYVNDF0TBKwF8yO5y9Bhk6LdjlVcUWLo3p/iXknRlCJDhxqj2FjEeCxoHEbvNwe66Xwud2KroTQZOlSXtLFJ0ZNjRd2dTbQarDxKlaGPujvqLIauiRHMPGTowNoCB8pChOD4QcxLhj5KDK8ao/r4Ya4yPAW7l6rWaCw1hNP4wyxX8Kjp8ZfE3/7a3d29FB5gZkKmv4b34VL9fsbiErv3kO729/ffiYlRa0SwaTh+8qd3i8XiRNRIzJpBdeVWrkGby4BRanQ1RbXNRSwZPNZdUNXz1RRDxNTcClnjcHUsGRxmWDt388auLXS1WTW9C7QeZzCpav0qkgzXkWTo0ibFLCvi2qOs9cg2qJRqjwPcdAv+e9AL6HD/paVw2ILHJ4BUt5fPDC/Bpfr/QsLFuo9rM3EzMEi/wo+mOQbWfZ1iQFz/PQSTP4lSwCoVDca2Ty10wQ+11q0l8E2eNcOF4Vgr27dMjQvgzaSNIeBM1o5TtUOWwSRmhCrwc1XgtzEKPKIMS8NxvGZYm+47YLMmEkE0dfkNVatp4Ju2HVbAqWRAqLgh9NulJqasY7TnjudbxsiH5BQiQ5LMNEyajboqS53rWlc7TD0e8gMRZWja7Sqpa9VGr2PJgKSsaom1m5uYsUQRtYOnDFjga1Xgb7Caxm6kzu4U9ybaxKN6unyIfPwmldBRsMiwxm9NV+A+35QUMsgRJqGi5JrrfSMiQI1KZtOzsMkQmtEy0V3LMZa5ofyacwxeOWXozeRRO5Qmgzp28mVuRBs/uNConlEWgWSJMqjjn2mai6jj/imEgGP+QTR109+zKFUGdY7kQuiW48sBayMM3dnpu5kly9C7/miFpYOIIYLiFBUEN22OgWTpMqhzJe9l6Nr60F4GdUc3Vq8lmDnI0Dtnk/Jcum+0DFh9bcibRk45+WVOMiDEcrkoo4nEZ/I+tqT3u9pMGjfMTQZ17iXRbAy6M2k4rlfQasrzSeOGOcrQQS18keGbdJC3wH2+0YYexbT3KuYsg7qOaNv5mCbnBszRoI5zI6Zi7jJ0ULvKqmTdvxrzSZrnYzoPRknz4t7gPB9MLTJ0OO7HcIuv680Aw+n2K9v7PHZ9Mckw3eBTbTJ0OEjhm1gGitxl6IgoxYplIChFhg65XSN5GyjCxmdyLsuQuQx9eiurXWaArVRc4TPxJzsZHhfqoAx7e3t400X3YfD5kSchz5CUkVdhTwnKsVgsjsQ2jzBhfjw+WBU+xzvf/FG1EOb5UvPn+0+fPp1QD2pNiqVm2IROHS+5ZkhNts0E0rqtcsYx+BV2s7DL5bCSiWUgyFoGJDBwekxyu+wO++bn6sm2BywDTfYyIC2xNX/sxDIUIAMit9vlYCS9bluWIQXFyCA02wFg1a+WuR9BwiX4XWQddoKdnTeQ/hSVkm1vgsBpfwjsiUCXqy/JUrg/wDy7Dz0WpckwCGxq1MDNuWpyVoZmI6/FpyNQUjORDM6ELZwPPWrPDJZBQ62ZwjIYMDyPcpaZwzIQqBHLlcP4xGwyiWXQoOYVuogwq8yyyFDfoJy6f3HtKcIspLDJgKmqfabldmm60+QRtfB1NtWqiwyYqnlOpiVo/C5CP0Pm0ta6yoAJOBQ1YHnUD7mWoXQpfGTAJGrBNDvZNsm0VCl8ZWhz2fNpDKRhx1ZVVZ5a3l+UFLbrJZrQqJuYZU8tUrhcp245oMxh36exmbsUrtdH7El5KWpkrlL4XJduYY8M2C1mNsxNCt/r0X32asYgKOYiRch1tJoBOjnV0v2cKF2KkPNLYkc7wWwpVYrQ846x52XxlCbFkPPF3KB01pQixdDz6MYgJt9QNFdylyLG8YkxCOc9IqojVyliHVfqn6hb7xiEC7lJEfN4us8FuC5kqpdcpIgtF/FZeAzChamlSFDT6MYgNoJxZyopUsQiumd38RhEAJGkkK6FmzAwvdAc761g/BkihSSePaUr5JFl4DGIIYRIId2nsjWmDclTyICpqqn3KfCVwlQYHimJDLXvlhMNVykMscOtY63BMpSCixTS8BBTx6aEZSgJmxS2whg7gGQZRsBTCqqLqZvBFHR/gWXIAFcpqIhet7Is5A4ky5ARDlKQK6NirJNgGTLEJIWpv6+bxeQzpMwyZAwhRePwnqeF6XTTiWUoALndghlnJuGG69cuvQUisDy0nIdlmCtSs5rK1MywDDOHmOuovfHEMlQAFPKZpoDfal7HMtQAcd9j8+Q1LENNtIY1lyxDhbT6GdGvWYZKITZHW7MMlaIbwmYZKkY3K5plqBhiCJtlqBmQomEZmO/ohrBZhooh9m+4FMwz/gfexgReSVrBWwAAAABJRU5ErkJggg=="

/***/ }),

/***/ "./src/components/images/logo/speed-24px.svg":
/*!***************************************************!*\
  !*** ./src/components/images/logo/speed-24px.svg ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/speed-24px.1addfeef.svg";

/***/ }),

/***/ "./src/components/images/sncf.JPG":
/*!****************************************!*\
  !*** ./src/components/images/sncf.JPG ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/media/sncf.3e46bbb9.JPG";

/***/ }),

/***/ "./src/index.css":
/*!***********************!*\
  !*** ./src/index.css ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-3-1!../node_modules/postcss-loader/src??postcss!./index.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/index.css");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(true) {
	module.hot.accept(/*! !../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-3-1!../node_modules/postcss-loader/src??postcss!./index.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/index.css", function() {
		var newContent = __webpack_require__(/*! !../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-3-1!../node_modules/postcss-loader/src??postcss!./index.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/index.css");

		if(typeof newContent === 'string') newContent = [[module.i, newContent, '']];

		var locals = (function(a, b) {
			var key, idx = 0;

			for(key in a) {
				if(!b || a[key] !== b[key]) return false;
				idx++;
			}

			for(key in b) idx--;

			return idx === 0;
		}(content.locals, newContent.locals));

		if(!locals) throw new Error('Aborting CSS HMR due to changed css-modules locals.');

		update(newContent);
	});

	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./src/index.js":
/*!**********************!*\
  !*** ./src/index.js ***!
  \**********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom */ "./node_modules/react-dom/index.js");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _index_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./index.css */ "./src/index.css");
/* harmony import */ var _index_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_index_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var bootstrap_dist_css_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! bootstrap/dist/css/bootstrap.min.css */ "./node_modules/bootstrap/dist/css/bootstrap.min.css");
/* harmony import */ var bootstrap_dist_css_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(bootstrap_dist_css_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _App__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./App */ "./src/App.js");
/* harmony import */ var _serviceWorker__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./serviceWorker */ "./src/serviceWorker.js");
var _jsxFileName = "C:\\wamp64\\www\\avenir-green\\avenir-green\\src\\index.js";






react_dom__WEBPACK_IMPORTED_MODULE_1___default.a.render( /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.StrictMode, {
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 9,
    columnNumber: 3
  }
}, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_App__WEBPACK_IMPORTED_MODULE_4__["default"], {
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 10,
    columnNumber: 5
  }
})), document.getElementById('root')); // If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA

_serviceWorker__WEBPACK_IMPORTED_MODULE_5__["unregister"]();

/***/ }),

/***/ "./src/serviceWorker.js":
/*!******************************!*\
  !*** ./src/serviceWorker.js ***!
  \******************************/
/*! exports provided: register, unregister */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "register", function() { return register; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "unregister", function() { return unregister; });
// This optional code is used to register a service worker.
// register() is not called by default.
// This lets the app load faster on subsequent visits in production, and gives
// it offline capabilities. However, it also means that developers (and users)
// will only see deployed updates on subsequent visits to a page, after all the
// existing tabs open on the page have been closed, since previously cached
// resources are updated in the background.
// To learn more about the benefits of this model and instructions on how to
// opt-in, read https://bit.ly/CRA-PWA
const isLocalhost = Boolean(window.location.hostname === 'localhost' || // [::1] is the IPv6 localhost address.
window.location.hostname === '[::1]' || // 127.0.0.0/8 are considered localhost for IPv4.
window.location.hostname.match(/^127(?:\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)){3}$/));
function register(config) {
  if (false) {}
}

function registerValidSW(swUrl, config) {
  navigator.serviceWorker.register(swUrl).then(registration => {
    registration.onupdatefound = () => {
      const installingWorker = registration.installing;

      if (installingWorker == null) {
        return;
      }

      installingWorker.onstatechange = () => {
        if (installingWorker.state === 'installed') {
          if (navigator.serviceWorker.controller) {
            // At this point, the updated precached content has been fetched,
            // but the previous service worker will still serve the older
            // content until all client tabs are closed.
            console.log('New content is available and will be used when all ' + 'tabs for this page are closed. See https://bit.ly/CRA-PWA.'); // Execute callback

            if (config && config.onUpdate) {
              config.onUpdate(registration);
            }
          } else {
            // At this point, everything has been precached.
            // It's the perfect time to display a
            // "Content is cached for offline use." message.
            console.log('Content is cached for offline use.'); // Execute callback

            if (config && config.onSuccess) {
              config.onSuccess(registration);
            }
          }
        }
      };
    };
  }).catch(error => {
    console.error('Error during service worker registration:', error);
  });
}

function checkValidServiceWorker(swUrl, config) {
  // Check if the service worker can be found. If it can't reload the page.
  fetch(swUrl, {
    headers: {
      'Service-Worker': 'script'
    }
  }).then(response => {
    // Ensure service worker exists, and that we really are getting a JS file.
    const contentType = response.headers.get('content-type');

    if (response.status === 404 || contentType != null && contentType.indexOf('javascript') === -1) {
      // No service worker found. Probably a different app. Reload the page.
      navigator.serviceWorker.ready.then(registration => {
        registration.unregister().then(() => {
          window.location.reload();
        });
      });
    } else {
      // Service worker found. Proceed as normal.
      registerValidSW(swUrl, config);
    }
  }).catch(() => {
    console.log('No internet connection found. App is running in offline mode.');
  });
}

function unregister() {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.ready.then(registration => {
      registration.unregister();
    }).catch(error => {
      console.error(error.message);
    });
  }
}

/***/ }),

/***/ 1:
/*!**************************************************************************************************************!*\
  !*** multi (webpack)/hot/dev-server.js ./node_modules/react-dev-utils/webpackHotDevClient.js ./src/index.js ***!
  \**************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(/*! C:\wamp64\www\avenir-green\avenir-green\node_modules\webpack\hot\dev-server.js */"./node_modules/webpack/hot/dev-server.js");
__webpack_require__(/*! C:\wamp64\www\avenir-green\avenir-green\node_modules\react-dev-utils\webpackHotDevClient.js */"./node_modules/react-dev-utils/webpackHotDevClient.js");
module.exports = __webpack_require__(/*! C:\wamp64\www\avenir-green\avenir-green\src\index.js */"./src/index.js");


/***/ })

},[[1,"runtime-main",0]]]);
//# sourceMappingURL=main.chunk.js.map